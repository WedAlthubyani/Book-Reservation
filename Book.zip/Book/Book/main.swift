//
//  main.swift
//  Book
//
//  Created by Wed Althubyani on 23/05/1443 AH.
//

import Foundation

print("___________*____________")

print("What is your name?")
if let name = readLine() {
    print("Hello \(String(describing: name)), Welcome to Book Club")
}
print("___________*____________")
print("1. Make a Reservation")
print("2. Cancel my Reservation")
print("3. Save the book")
print("4. Exit")
print("___________*____________")
print("Select your choice")



var Bookslist = ["Wonder", "Five feet apart", "Magnolia", "November 9"]
var userBook : [String] = []

let Reservation = """
1. Make a Reservation"
2. Cancel my Reservation"
3. Save the book"
4. Exit"
"""

var userInput = ""
repeat {
if let userChoice = readLine(){
    userInput = userChoice
    switch userChoice {
    case "1":
        print(Bookslist)
    case "2":
        print("cancel")
    case "3":
        print("save ")
        addNewBook ()
    case "4":
        print("see you later !!")
    default :
        print("Please select..")
        
        
    }
}
}while userInput != "4"

func addNewBook ()
{
    print("please enter the book name")
    if let userChoice = readLine(){
        userBook.append(userChoice)
    }
    
    print(userBook)
    
}


